package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int peso;
    float altura;
    float imc;
    String mensagem = "";

    EditText Peso, Altura;
    TextView txtResultado;
    Button buttonCalcular;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Peso = (EditText) findViewById(R.id.Peso);
        Altura = (EditText) findViewById(R.id.Altura);
        txtResultado = (TextView) findViewById(R.id.Resultado);
        buttonCalcular = (Button) findViewById(R.id.buttonCalcular);

        buttonCalcular.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                peso = Integer.parseInt(Peso.getText().toString());
                altura = Float.parseFloat(Altura.getText().toString());
                imc = peso / (altura * altura);

                if (imc < 18.5) { mensagem = "Abaixo do Peso"; }
                else if ((imc >= 18.5) && (imc < 25)) { mensagem = "Peso Ideal"; }
                else if ((imc >= 25.0) && (imc < 30.0)) { mensagem = "Levemente acima do Peso"; }
                else if ((imc >= 30.0) && (imc < 35.0)) { mensagem = "Obesidade Grau I"; }
                else if ((imc >= 35.0) && (imc < 40.0)) { mensagem = "Obesidade Grau II (Severa)"; }
                else { mensagem = "Obesidade Grau III (Mórbida)"; }

                txtResultado.setText("IMC: " +String.valueOf(imc) + "\nMensagem: " + mensagem);

            }
        });
    }
}